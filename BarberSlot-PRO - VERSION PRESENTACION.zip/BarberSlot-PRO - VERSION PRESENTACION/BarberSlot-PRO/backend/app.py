import datetime
from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL

app = Flask(__name__,
            template_folder='../frontend/templates',
            static_folder='../frontend/static')

app.secret_key = "barberslot_secret"

# CONFIGURACIÓN MYSQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'barberslot'
app.config['MYSQL_PORT'] = 3306

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nombre = request.form['nombre']
        correo = request.form['correo']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO usuarios(nombre, correo, password, rol) VALUES (%s,%s,%s,'cliente')",
                    (nombre, correo, password))
        mysql.connection.commit()
        cur.close()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form['correo']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, nombre, rol FROM usuarios WHERE correo=%s AND password=%s",
                    (correo, password))
        user = cur.fetchone()
        cur.close()
        if user:
            session['user_id'] = user[0]
            session['user'] = user[1]
            session['rol'] = user[2]
            return redirect('/admin' if user[2] == 'admin' else '/dashboard')
    return render_template('login.html')

# --- RUTAS DASHBOARD CLIENTE ---

@app.route('/dashboard')
def dashboard():
    if 'user' not in session: return redirect('/login')
    return render_template('dashboard.html', user=session['user'])

@app.route('/dashboard/reservas', methods=['GET', 'POST'])
def reservas():
    if 'user_id' not in session: return redirect('/login')
    cur = mysql.connection.cursor()
    
    cur.execute("SELECT * FROM servicios")
    servicios = cur.fetchall()
    cur.execute("SELECT * FROM barberos")
    barberos = cur.fetchall()

    if request.method == 'POST':
        fecha = request.form['fecha']
        hora = request.form['hora']
        servicio_id = request.form['servicio']
        barbero_id = request.form['barbero']

        # Lógica de validación de día
        fecha_obj = datetime.datetime.strptime(fecha, "%Y-%m-%d")
        dias = ["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"]
        dia = dias[fecha_obj.weekday()]

        cur.execute("""
            SELECT * FROM horarios 
            WHERE barbero_id=%s AND LOWER(dia) = LOWER(%s) 
            AND hora_inicio <= %s AND hora_fin >= %s
        """, (barbero_id, dia, hora, hora))
        
        if not cur.fetchone():
            return f"Error: El barbero no tiene turno disponible el {dia} a las {hora}."

        cur.execute("INSERT INTO citas (fecha, hora, servicio, usuario_id) VALUES (%s,%s,%s,%s)",
                    (fecha, hora, servicio_id, session['user_id']))
        cita_id = cur.lastrowid
        
        cur.execute("SELECT precio FROM servicios WHERE id=%s", (servicio_id,))
        precio = cur.fetchone()[0]

        cur.execute("INSERT INTO pagos (cita_id, monto, metodo, estado) VALUES (%s, %s, %s, %s)",
                    (cita_id, precio, 'Efectivo', 'Pendiente'))
        
        mysql.connection.commit()
        cur.close()
        return redirect('/dashboard/mis-citas')

    return render_template('dashboard_reservas.html', servicios=servicios, barberos=barberos)

@app.route('/dashboard/mis-citas')
def mis_citas():
    if 'user_id' not in session: return redirect('/login')
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT c.fecha, c.hora, s.nombre, 'Pendiente'
        FROM citas c
        JOIN servicios s ON c.servicio = s.id
        WHERE c.usuario_id = %s
    """, (session['user_id'],))
    datos = cur.fetchall()
    cur.close()
    
    citas = [{'fecha': d[0], 'hora': d[1], 'servicio': d[2], 'estado': d[3]} for d in datos]
    return render_template('dashboard_mis_citas.html', citas=citas)

# --- RUTAS ADMIN --- (Simplificadas para espacio)
@app.route('/admin')
def admin():
    # Lógica de admin...
    return render_template('admin_dashboard.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)